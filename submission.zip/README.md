## Setup environment
```
conda create --name main-ds python=3.8
conda activate main-ds
pip install numpy pandas matplotlib seaborn jupyter streamlit
```

## Run steamlit app
```
streamlit run app.py
```